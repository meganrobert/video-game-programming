using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace ColorBox
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Random random = new Random();

        string scoreboard = "score ";
        Rectangle redLanding;
        Rectangle yellowLanding;
        Rectangle greenLanding;
        Rectangle blueLanding;


        Texture2D blockTexture;
        Rectangle activeBlock;
        Color blockColor;
        Color returnColor;

        Boolean fallen = false;
        Boolean landed = false;

        bool powerUpUsed;
        Color goalColor;
        int score;
        int round;
        int speed;
        int goalCorrectDrops;
        int goalWrongDrops;
        int correctDrops;
        int wrongDrops;
        int powerups;
        Boolean winner;
        Boolean gameOver;
        String message;
        bool fastDropActivated = false;
        int fastDropSpeedIncrease = 1;
        String powerUpText;
        Color powerUpTextColor;
        bool powerUpActivated; 

        SpriteFont font1;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferHeight = 1000;
            graphics.PreferredBackBufferWidth = 800;

            Window.Title = "Score: " + correctDrops + "/" + goalCorrectDrops + "   Round: " + round;
        }

        protected override void Initialize()
        {
            //landing zones
            redLanding = new Rectangle(0, 950, 200, 50);
            yellowLanding = new Rectangle(200, 950, 200, 50);
            greenLanding = new Rectangle(400, 950, 200, 50);
            blueLanding = new Rectangle(600, 950, 200, 50);

            // falling block rect
            activeBlock = new Rectangle(random.Next(0, 750), 10, 40, 40);

            correctDrops = 0;
            powerups = 4;
            powerUpUsed = false;
            message = "";
            powerUpText = "";
            wrongDrops = 0;
            speed = 3;
            powerUpTextColor = Color.White;
            powerUpActivated = false; 
            round = 1;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            blockTexture = this.Content.Load<Texture2D>("whiteRectangle");

            // Load font here
            font1 = this.Content.Load<SpriteFont>("SpriteFont1");
        }

        protected override void Update(GameTime gameTime)
        {
            // Exit the game if Back button is pressed
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            IsMouseVisible = true;

            GamePadState pad1 = GamePad.GetState(PlayerIndex.One);

            if (pad1.Buttons.A == ButtonState.Pressed || pad1.Buttons.B == ButtonState.Pressed || pad1.Buttons.X == ButtonState.Pressed || pad1.Buttons.Y == ButtonState.Pressed)
            {
                powerUpActivated = true;
            }

            // change color with powerups
            pad1 = powerUps(pad1);

            // move the falling block 
            float activeBlockX = pad1.ThumbSticks.Left.X;
            float activeBlockY = pad1.ThumbSticks.Left.Y;

            activeBlock.X = (int)(activeBlock.X + (speed * activeBlockX));
            activeBlock.Y = (int)(activeBlock.Y - (speed * activeBlockY));
            // fast drop
            fastDrop(pad1);

            // switch rounds
            switchRounds();

            // apply speed
            activeBlock.Y += fastDropActivated ? speed * 2 : speed;

            // check if landed
            if (activeBlock.Y > 910)
            {
                landed = true;
                gameScore(activeBlock);
                activeBlock.Y = -50;
                activeBlock.X = random.Next(0, 750);
                blockColor = randomizeBlockColor();
                goalColor = blockColor;
                fastDropActivated = false;

                // do once the round is over - either check if won or lost or next round
                roundOver();

                landed = false;

                powerUpText = "";
                powerUpActivated = false;
            }

            // update window title
            Window.Title = "Score: " + correctDrops + "/" + goalCorrectDrops + "|   Round: " + round + "| Powerups: " + powerups;

            base.Update(gameTime);
        }



        private void roundOver()
        {
            if (round < 3 && correctDrops == goalCorrectDrops)
            {
                correctDrops = 0;
                wrongDrops = 0;
                round++;
            }

            // check if lost
            if (wrongDrops > goalWrongDrops)
            {
                gameOver = true;
                winner = false;
                message = "You lost :(";
            }
            if (round == 3 && correctDrops == 20)
            {
                round = 3;
                correctDrops = 20;
                winner = true;
                gameOver = true;
                message = "You Won!";
            }
        }

        private bool aButtonPressed, bButtonPressed, yButtonPressed, xButtonPressed;

        private GamePadState powerUps(GamePadState pad1)
        {
            if (pad1.Buttons.A == ButtonState.Pressed && powerups > 0 && !aButtonPressed)
            {
                blockColor = Color.Green;
                goalColor = blockColor;
                powerUpText = "Power up activated. Color change to Green";
                powerUpTextColor = Color.Green; 
                powerups--; 
                aButtonPressed = true; 
            }
            else if (pad1.Buttons.A == ButtonState.Released)
            {
                aButtonPressed = false; 
            }

            if (pad1.Buttons.B == ButtonState.Pressed && powerups > 0 && !bButtonPressed)
            {
                blockColor = Color.Red;
                goalColor = blockColor;
                powerUpText = "Power up activated. Color change to Red";
                powerUpTextColor = Color.Red;
                powerups--;
                bButtonPressed = true;
            }
            else if (pad1.Buttons.B == ButtonState.Released)
            {
                bButtonPressed = false;
            }

            if (pad1.Buttons.Y == ButtonState.Pressed && powerups > 0 && !yButtonPressed)
            {
                blockColor = Color.Yellow;
                goalColor = blockColor;
                powerUpText = "Power up activated. Color change to Yellow";
                powerUpTextColor = Color.Yellow;
                powerups--;
                yButtonPressed = true;
            }
            else if (pad1.Buttons.Y == ButtonState.Released)
            {
                yButtonPressed = false;
            }

            if (pad1.Buttons.X == ButtonState.Pressed && powerups > 0 && !xButtonPressed)
            {
                blockColor = Color.Blue;
                goalColor = blockColor;
                powerUpText = "Power up activated. Color change to Blue";
                powerUpTextColor = Color.Blue;
                powerups--;
                xButtonPressed = true;
            }
            else if (pad1.Buttons.X == ButtonState.Released)
            {
                xButtonPressed = false;
            }

            return pad1;
        }



        private void fastDrop(GamePadState pad1)
        {
            if (pad1.Triggers.Left == 1.0f && !fastDropActivated)
            {
                fastDropActivated = true;
            }
        }

        private void switchRounds()
        {
            switch (round)
            {
                case 1:
                    goalCorrectDrops = 6;
                    goalWrongDrops = 3;
                    speed = random.Next(2, 5);
                    break;
                case 2:
                    goalCorrectDrops = 10;
                    goalWrongDrops = 5;
                    speed = random.Next(6, 8);
                    break;
                case 3:
                    goalCorrectDrops = 20;
                    goalWrongDrops = 10;
                    speed = random.Next(8, 11);
                    break;
            }
        }

        private void gameScore(Rectangle block)
        {
            if (goalColor == Color.Black)
            {
                correctDrops++;
            }
            else if ((block.X > 0 && block.X < 200) && goalColor == Color.Red)
            {
                correctDrops++;
            }
            else if ((block.X > 200 && block.X < 400) && goalColor == Color.Yellow)
            {
                correctDrops++;
            }
            else if ((block.X > 400 && block.X < 600) && goalColor == Color.Green)
            {
                correctDrops++;
            }
            else if ((block.X > 600) && goalColor == Color.Blue)
            {
                correctDrops++;
            }
            else
            {
                wrongDrops++;
            }
        }

        private Color randomizeBlockColor()
        {
            int randomColor = random.Next(5);
            int blackColor = random.Next(10);

            if (blackColor == 1)
            {
                returnColor = Color.Black;
            }
            else
            {
                switch (randomColor)
                {
                    case 1:
                        returnColor = Color.Red;
                        break;
                    case 2:
                        returnColor = Color.Yellow;
                        break;
                    case 3:
                        returnColor = Color.Green;
                        break;
                    case 4:
                        returnColor = Color.Blue;
                        break;
                }
            }
            return returnColor;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            if (gameOver)
            {
                GraphicsDevice.Clear(Color.White);
                spriteBatch.DrawString(font1, "Game Over. " + message, new Vector2(350, 500), Color.Blue);
            }
            else
            {
                // landing zones
                spriteBatch.Draw(blockTexture, redLanding, Color.Red);
                spriteBatch.Draw(blockTexture, yellowLanding, Color.Yellow);
                spriteBatch.Draw(blockTexture, greenLanding, Color.Green);
                spriteBatch.Draw(blockTexture, blueLanding, Color.Blue);

                // falling block
                spriteBatch.Draw(blockTexture, activeBlock, blockColor);

                if (fastDropActivated)
                {
                    spriteBatch.DrawString(font1, "Fast Drop Activated", new Vector2(40, 500), Color.Maroon);
                }

                if (powerUpActivated && activeBlock.Y < 910)
                {
                    spriteBatch.DrawString(font1, powerUpText, new Vector2(40, 520), powerUpTextColor);
                }
                else if (activeBlock.Y >= 910)
                {
                    powerUpText = ""; 
                }
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }

    }
}
